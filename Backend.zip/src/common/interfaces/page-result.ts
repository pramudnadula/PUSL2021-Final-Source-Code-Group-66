export interface PageResult {
  count: number;
  data: any[];
}
