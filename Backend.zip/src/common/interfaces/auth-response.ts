export interface AuthResponse {
  error?: boolean;
  message?: string;
  token?: string;
}
